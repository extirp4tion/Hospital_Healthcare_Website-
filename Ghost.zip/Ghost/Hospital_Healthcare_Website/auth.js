const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cors = require('cors');  // Убедитесь, что cors импортирован

const app = express();
const db = new sqlite3.Database('database.db');
const SECRET_KEY = 'your_secret_key'; // Используйте переменные окружения в реальных проектах для безопасности

app.use(cors());  // Убедитесь, что cors используется
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'html');
app.engine('html', require('ejs').renderFile);

db.serialize(() => {
  db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT, email TEXT UNIQUE, password TEXT, token TEXT)");
  db.run("CREATE TABLE IF NOT EXISTS appointments (name TEXT, number TEXT, date TEXT, time TEXT)");
});

app.get('/', (req, res) => {
  res.render('index');
});

app.post('/register', (req, res) => {
  const { name, email, password } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 8);
  db.run("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", [name, email, hashedPassword], (err) => {
    if (err) {
      return res.status(500).send("Error registering user.");
    }
    res.status(200).send("User registered successfully!");
  });
});

app.post('/login', (req, res) => {
  const { email, password } = req.body;
  db.get("SELECT * FROM users WHERE email = ?", [email], (err, user) => {
    if (err) return res.status(500).send("Error on the server.");
    if (!user) return res.status(404).send("No user found.");

    const passwordIsValid = bcrypt.compareSync(password, user.password);
    if (!passwordIsValid) return res.status(401).send({ auth: false, token: null });

    const token = jwt.sign({ id: user.id }, SECRET_KEY, { expiresIn: 86400 }); // 24 часа
    db.run("UPDATE users SET token = ? WHERE id = ?", [token, user.id], (err) => {
      if (err) return res.status(500).send("Error updating token.");
      res.json({ auth: true, token: token });
    });
  });
});

function verifyToken(req, res, next) {
  const token = req.headers['x-access-token'];
  if (!token) return res.status(403).send({ auth: false, message: 'No token provided.' });
  console.loq(token)
  db.get("SELECT * FROM users WHERE token = ?", [token], (err, user) => {
    if (err) return res.status(500).send({ auth: false, message: 'Failed to authenticate token.' });
    if (!user) return res.status(404).send("No user found.");

    jwt.verify(token, SECRET_KEY, (err, decoded) => {
      if (err) return res.status(500).send({ auth: false, message: 'Failed to authenticate token.' });

      req.userId = decoded.id;
      next();
    });
  });
}

app.get('/profile',  (req, res) => {
  res.render('profile'); // Убедитесь, что у вас есть представление profile.html
});

app.get('/profile-data', verifyToken, (req, res) => {
  db.get("SELECT name FROM users WHERE token = ?", [req.headers['x-access-token']], (err, user) => {
    if (err) return res.status(500).send("Error on the server.");
    if (!user) return res.status(404).send("No user found.");

    db.all("SELECT date, time FROM appointments WHERE name = ?", [user.name], (err, appointments) => {
      if (err) return res.status(500).send("Error on the server.");
      res.json({ name: user.name, appointments: appointments });
    });
  });
});


app.listen(3000, () => {
  console.log('Server is running on port 3000');
});

