const fs = require('fs');

// Укажите путь к вашему файлу базы данных
const filePath = 'd:/Ghost/Hospital_Healthcare_Website/database.db';

fs.stat(filePath, (err, stats) => {
    if (err) {
        console.error('Ошибка чтения информации о файле:', err.message);
        return;
    }

    console.log(`Права доступа: ${stats.mode.toString(8)}`);
    
    // Проверка прав доступа (например, только для чтения и записи владельцем)
    const ownerRead = stats.mode & fs.constants.S_IRUSR;
    const ownerWrite = stats.mode & fs.constants.S_IWUSR;
    const ownerExecute = stats.mode & fs.constants.S_IXUSR;

    console.log(`Владелец - Чтение: ${ownerRead ? 'Да' : 'Нет'}`);
    console.log(`Владелец - Запись: ${ownerWrite ? 'Да' : 'Нет'}`);
    console.log(`Владелец - Выполнение: ${ownerExecute ? 'Да' : 'Нет'}`);
});

// Пример использования sync метода для получения прав доступа
try {
    const stats = fs.statSync(filePath);
    console.log(`Права доступа: ${stats.mode.toString(8)}`);
    
    const ownerRead = stats.mode & fs.constants.S_IRUSR;
    const ownerWrite = stats.mode & fs.constants.S_IWUSR;
    const ownerExecute = stats.mode & fs.constants.S_IXUSR;

    console.log(`Владелец - Чтение: ${ownerRead ? 'Да' : 'Нет'}`);
    console.log(`Владелец - Запись: ${ownerWrite ? 'Да' : 'Нет'}`);
    console.log(`Владелец - Выполнение: ${ownerExecute ? 'Да' : 'Нет'}`);
} catch (err) {
    console.error('Ошибка чтения информации о файле:', err.message);
}